//
//  ViewController.swift
//  loadHtmlStringswift
//
//  Created by cricket21 on 15/03/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var myWebView: UIWebView!
    
    
    var dict_response=NSMutableDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        //self.AI.startAnimating()
        
    }

    func loadData()  {
        var request = URLRequest(url:URL(string: "http://api.cricket-21.com/JsonResoruce/T20%20Domestic/541/others.json")!)
        
        let session = URLSession.shared
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let task = session.dataTask(with: request, completionHandler: {data, response, error -> Void in
            guard error == nil && data != nil else
            {
                print("error=\(error)")
                return
            }
            
            do
            { try
                self.dict_response = JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSMutableDictionary
                print(self.dict_response)
                let ticket=self.dict_response["Tickets"]as!NSString
                DispatchQueue.main.async { () -> Void in
                    
                self.myWebView .loadHTMLString(ticket as String, baseURL: nil)
                   
                }
            }
            catch
            {
                print("Error Execption")
                            }
            
            
            
        })
        task.resume()
    }
    }


